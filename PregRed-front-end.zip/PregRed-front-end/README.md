# PregRed
Readiness Checker for Healthy Delivery - GUI
