import React from 'react';

import './Prediction.css';

function Prediction() {
  return <h1> PregRed App is Running - Prediction </h1>;
}

export default Prediction;
