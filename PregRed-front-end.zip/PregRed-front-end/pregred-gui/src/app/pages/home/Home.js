import React from 'react';

import './Home.css';

function Home() {
  return <h1> PregRed App is Running - Home </h1>;
}

export default Home;
